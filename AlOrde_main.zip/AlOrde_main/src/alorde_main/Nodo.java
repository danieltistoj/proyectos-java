
package alorde_main;


public class Nodo {
    private int dato;
    private Nodo Sig;

    public int getDato() {
        return dato;
    }

    public void setDato(int dato) {
        this.dato = dato;
    }

    public Nodo getSig() {
        return Sig;
    }

    public void setSig(Nodo Sig) {
        this.Sig = Sig;
    }
    

   
    
}

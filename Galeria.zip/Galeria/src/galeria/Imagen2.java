/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package galeria;

/**
 *
 * @author Usuario
 */
public class Imagen2 {
      private String[] imagenes={"galeria\\imagen1.jpg"
            ,"galeria\\imagen2.jpg"
            ,"galeria\\imagen3.jpg"
            ,"galeria\\imagen4.jpg"
            ,"galeria\\imagen5.jpg"
            ,"galeria\\imagen6.jpg"
            ,"galeria\\imagen7.jpg"
            ,"galeria\\imagen8.jpg"
            ,"galeria\\imagen9.jpg"
            ,"galeria\\imagen10.jpg"};

    public String[] getImagenes() {
        return imagenes;
    }

    public void setImagenes(String[] imagenes) {
        this.imagenes = imagenes;
    }
      
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transacciones_1_0;

/**
 *
 * @author Sammy Guergachi <sguergachi at gmail.com>
 */
public class Transacciones_1_0 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Formulario formulario = new Formulario();
       formulario.setVisible(true);
       
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arboles_binarios;

/**
 *
 * @author Usuario
 */
public class Arboles_Binarios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
     Arbol arbol = new Arbol();
     arbol.Insertar(6);
     arbol.Insertar(3);
     arbol.Insertar(9);
     arbol.Insertar(15);
     arbol.Insertar(20);
     
     System.out.println(arbol.Ordenar_In());
     System.out.println(arbol.Ordenar_Pos());
     System.out.println(arbol.Ordenar_Pre());
*/
     
     Ventana ventana = new Ventana();
    }
    
}

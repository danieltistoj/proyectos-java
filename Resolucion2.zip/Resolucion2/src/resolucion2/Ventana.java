/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package resolucion2;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Usuario
 */
public class Ventana {
     private JFrame ventana;
    private JPanel panel_img, panel_flechas, panel_cargar, informacion;
    private JButton boton_izq, boton_der, boton_cargar,boton_ordenar,boton_borrar;
    private JLabel url1,nombre1,size1,numero1, url2,nombre2,size_2,numero_2;
    private JTextField url, nombre, size, numero;
    private Nodo auxiliar;
    private boolean Inicio=false;
    private Lista lista = new Lista();
    
    public Ventana(){
        nombre2  = new JLabel("Nombre:");
        size_2 = new JLabel("Size:");
        numero_2 = new JLabel("Numero:");
        url2 = new JLabel("URL: ");
        
        nombre2.setBounds(230, 20, 100, 20);
        size_2.setBounds(230, 80, 100, 20);
        numero_2.setBounds(230,140, 100, 20);
        url2.setBounds(230, 200, 350, 20);
        
  
        url1 = new JLabel("URL");
        url1.setBounds(0, 0, 100, 20);
        url = new JTextField();
        url.setBounds(0, 20, 70, 20);
        
        nombre1 = new JLabel("NOMBRE");
        nombre1.setBounds(0, 80, 100, 20);
        nombre = new JTextField();
        nombre.setBounds(0, 100, 70, 20);
        
        size1 = new JLabel("SIZE");
        size1.setBounds(0, 160, 70, 20);
        size = new JTextField();
        size.setBounds(0, 180, 70, 20);
        
        numero1 = new JLabel("NUMERO");
        numero1.setBounds(0, 240, 70, 20);
        numero = new JTextField();
        numero.setBounds(0, 260, 70, 20);


        boton_der = new JButton("sig");
        boton_der.setBounds(210,0, 70, 30);
      
        boton_izq = new JButton("ant");
        boton_izq.setBounds(70, 0, 70, 30);
        
        boton_cargar = new JButton("Cargar");
        boton_cargar.setBounds(60,320, 80, 30);
        
        boton_ordenar = new JButton("Ordenar");
        boton_ordenar.setBounds(100,0,100,50);
        boton_borrar = new JButton("Eliminar");
        boton_borrar.setBounds(100, 100, 100, 50);
       
        //inicializar paneles
        informacion = new JPanel();
        informacion.setBounds(0, 430,600, 270);
        informacion.setLayout(null);
        informacion.setVisible(true);
        informacion.add(numero_2);
        informacion.add(nombre2);
        informacion.add(size_2);
        informacion.add(boton_ordenar);
        informacion.add(boton_borrar);
        informacion.add(url2);

        
        panel_img = new JPanel();
        panel_img.setBounds(200, 0, 400, 400);
        panel_img.setBackground(Color.WHITE);
        panel_img.setLayout(null);
        panel_img.setVisible(true);
        
        panel_flechas = new JPanel();
        panel_flechas.setBounds(200,400, 400,30);
        panel_flechas.setLayout(null);
        panel_flechas.setVisible(true);
        
        
        panel_cargar = new JPanel();
        panel_cargar.setBounds(0,0, 200,400);
        panel_cargar.setBackground(Color.LIGHT_GRAY);
        panel_cargar.setLayout(null);
        panel_cargar.setVisible(true);
        panel_cargar.add(url);
        panel_cargar.add(url1);
        panel_cargar.add(nombre);
        panel_cargar.add(nombre1);
        panel_cargar.add(size1);
        panel_cargar.add(size);
        panel_cargar.add(numero);
        panel_cargar.add(numero1);
        panel_cargar.add(boton_cargar);
        
        //agregar a panel botones
        panel_flechas.add(boton_der);
        panel_flechas.add(boton_izq);
       // panel_cargar.add(boton_cargar);
         
        //inicializar ventana
     ventana = new JFrame("Galeria");
     ventana.setSize(600, 700);
     ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     ventana.setLocationRelativeTo(null);
     ventana.setLayout(null);
     ventana.setResizable(false);
     
     // *** ACCION DE BOTONES ***
     //boton cargar
     boton_cargar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            Inicio = true;
            
            String text1 = url.getText();
       
            String text2 = nombre.getText();
          
            String text3 = size.getText();
            int size2 = Integer.parseInt(text3);
            
            String text4 = numero.getText();
            int numero2 = Integer.parseInt(text4);
            
            Imagen nueva_img = new Imagen(text1);
              
            Nodo nuevo_nodo = new Nodo();
            nuevo_nodo.setUrl(text1);
            nuevo_nodo.setNombre(text2);
            nuevo_nodo.setSize(size2);
            nuevo_nodo.setNumero(numero2);
            nuevo_nodo.setClase_img(nueva_img);
            lista.Inst_fondo(nuevo_nodo);
            
               if(lista.getSize()==1){
                auxiliar = lista.getTope();   
                panel_img.add(lista.getTope().getClase_img().getLabel());
                Datos(auxiliar);
                informacion.repaint();
                panel_img.repaint();
       
                
            }
       
           
            }
        });
     //boton para mover a la derecha
     boton_der.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(Inicio){
                    if(auxiliar.getSig()!=null){
                    panel_img.remove(auxiliar.getClase_img().getLabel());
                    auxiliar = auxiliar.getSig();
                    Datos(auxiliar);
                    panel_img.add(auxiliar.getClase_img().getLabel());
                    panel_img.repaint();
                    }
                }
                
            }
        });
     //boton para mover a la izquierda
     boton_izq.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(Inicio){
                    if(auxiliar.getAnt()!=null){
                    panel_img.remove(auxiliar.getClase_img().getLabel());
                    auxiliar = auxiliar.getAnt();
                    Datos(auxiliar);
                    panel_img.add(auxiliar.getClase_img().getLabel());
                    panel_img.repaint();
                    }
                }
                
            }
        });
     boton_ordenar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(lista.Vacia()){
                    JOptionPane.showMessageDialog(null,"La lista esta vacia","Error",JOptionPane.ERROR_MESSAGE); 
                }
                else{
                    lista.Ordenar();
                    auxiliar = lista.getTope();
                    Datos(auxiliar);
                }
            }
        });
     
     boton_borrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               if(lista.Vacia()){
                   JOptionPane.showMessageDialog(null,"La lista esta vacia","Error",JOptionPane.ERROR_MESSAGE); 
 
                }
                else{
                int num = Integer.parseInt(JOptionPane.showInputDialog("intruduce tu edad"));
                Nodo aux = lista.Buscar(num);
                if(aux==null){
                    JOptionPane.showMessageDialog(null,"El estudiante no existe","Advertencia",JOptionPane.WARNING_MESSAGE); 

                }
                else{
                    if(lista.getSize()==1){
                       
                        nombre2.setText("Nombre: ");
                        numero_2.setText("Numero: ");
                        size_2.setText("Size: ");
                        panel_img.remove(auxiliar.getClase_img().getLabel());
                        panel_img.repaint();
                        informacion.repaint();
                        lista.Eliminar(num);
                        Inicio = false;
                    }
                    else{
                        if(auxiliar.getNumero()==num){
                        Anterio_Siguiente(aux);
                        lista.Eliminar(num);
                        }
                        else{
                           lista.Eliminar(num);  
                        }

                        
                        
                    }
                   
                }
                    
                }
              
            }
        });
     //FIN ACCION DE BOTONES
     
      ventana.add(panel_cargar);
      ventana.add(panel_flechas);
      ventana.add(panel_img);
      ventana.add(informacion);
      ventana.setVisible(true);
    }
    public void Datos(Nodo aux){
        nombre2.setText("Nombre: "+aux.getNombre());
        numero_2.setText("Numero: "+aux.getNumero());
        size_2.setText("Size: "+aux.getSize());
        url2.setText("URL: "+aux.getUrl());
        informacion.repaint();
    }
     public void Anterio_Siguiente(Nodo aux){
        if(aux.getSig()!=null){
              auxiliar = auxiliar.getSig();    
             Datos(auxiliar);
        }
        else{
              auxiliar = auxiliar.getAnt();        
              Datos(auxiliar);
            
        }
        
    }
}
